<?php
	include_once '../Models/ChoosenDog.php';
?>
	
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="utf-8">
		<title> Search a dog</title>
		<link rel="stylesheet" href="../Css/readMore.css" type="text/css">
	</head>
	
	<body>
	<div id="head">
			<header>
				<h2>DERBY'S DOGS</h2>
                <img src="../Img/rescueMe.jpg" alt="Dogs">
			</header>
     </div>
			
        <div id="nav">
            <nav>
                <div class="menu"><a href="Home.php">Home</a></div>
                <div class="menu"><a href="DogSearch.php">Dog search</a></div>
                <div class="menu"><a href="SponsorADog.php">Sponsor a dog</a></div>
                <div class="menu"><a href="Admin.php">Administrator</a></div>
            </nav>
        </div>
        
        
        </div>
	        <?php 
				if (isset ( $_GET ['page'] )) {
					$page = $_GET ['page'];
// 					print_r(information($page));
					$details= information($page);
					echo
					'<div id="results">
							<div id="details">
								<div id="detail">
									Name: '.$details[0].'
								</div>

								<div id="detail">
									Age: '.$details[1].' year(s)
								</div>

								<div id="detail"> 
									Gender: '.$details[3].'
								</div>
							</div>

							<div id="picture">
								<img src="'.$details[2].'" alt="">
							</div>
							<diV>
								<form action="#" method="post">
									<fieldset>
										<legend>SPONSORING</legend>
											<p>
												<label for="userid">User:</label>
													<input type="number" name="userId" id="userid">
												</p>
											<p>
												<label for="sdate">Date:</label>
													<input type="date" name="sDate" id="sdate">
											</p>
											<p>
												<label for="samount">Amount:</label>
													<input type="number" name="sAmount" id="samount">
											</p>
											<p>
												<input type="submit" name="sponsor" value="Sponsor">
											</p>
									</fieldset>
								</form>
							</div>
					</div>';
				}
				
				if (isset($_POST["sponsor"])){
					if(findUser($_POST["userId"]) != "1"){
						echo "<h3>PLEASE ENTER A CORRECT USER</h3>";
					}
					else {
						if(sponsor($_POST["userId"],$page, $_POST["sDate"], $_POST["sAmount"]) == "OK")
							echo "<h3>THANK YOU TO SPONSORING THIS DOG</h3>";
						else 
							echo "<h3>ERREUR SQL</h3>";
					}
				}
				?>
				 
  <div id="navFoot">
            <nav> 
                <div class="menu"><a href="SponsorADog.php">MAKE A DONNATION</a></div>
                <div class="menu"><a href="Admin.php">CONTACT US</a></div>
                <div class="menu"><a href="Home.php">SOCIAL NETWORK</a></div>
                <div class="menu"><a href="Home.php">ABOUT US...</a></div> 
            </nav>  
        </div>
        <div id="foot"> 
            <footer>
                <address>
                    Derby Dog Rescue.<br> 
                    Telephone Number 123-456-789<br>
                    2017 Derby Dogs<br>
                    Derby, UK
                </address>
                <p>Copyright (c)</p>
            </footer>
		</div>
	
	
	</body>
</html>