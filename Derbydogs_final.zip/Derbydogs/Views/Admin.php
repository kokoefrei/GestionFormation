<?php 
	include_once '../Models/Admin.php';
	$adopted = adopted();
	$sponsor = sponsor();
	$aCount = adoptedCount();
	$sCount = sponsorsCount();
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title> WELCOME TO DERBY DOGS </title>
        <link rel="stylesheet" href="../Css/admin.css" type="text/css">
	</head>
	<body>
	   <div id="head">
			<header> 
                    <h2>DERBY'S DOGS</h2>
                    <img src="../Img/rescueMe.jpg" alt="Dogs">
			</header>
        </div> 
			
		<div id="nav">	
            <nav>
                <div class="menu"><a href="Home.php">Home</a></div>
				<div class="menu"><a href="DogSearch.php">Dog search</a></div>
				<div class="menu"><a href="SponsorADog.php">Sponsor a dog</a></div>
				<div class="menu"><a href="Admin.php">Administrator</a></div>
			</nav>
        </div>
			
		<div>
			<form action="#" method="post">
				<fieldset>
					<legend> DELETE SECTION</legend>
					<p>
						<input type="submit" name="delete" value="DELETE ADOPTED DOGS">
					</p>
				</fieldset>
			</form>
		</div>
		
		
		<?php 
			if (isset($_POST["delete"])){
				if (sDelete()=="OK" && dDelete() == "OK")
					echo "OPERATION EFFECTUEE";
				else 
					echo "ERREUR SQL";
			}
		
		?>
		
        <div id="section">
            <div class="introducing">
                ADOPTED DOGS
            </div>
            <?php 
            	$i = 0;
            	while ($i < $aCount){
		            echo 
			            '<div class="article" id="scrollbar">
			            	<h2>'.$adopted[$i][0].'</h2>
			                <img alt="dogPicture" src="'.$adopted[$i][1].'">
			            </div>';
	            	$i++;
	            }
            ?>
            
        </div>
        
        <div id="section">
            <div class="introducing">
               SPONSORS
            </div>
            
            <?php 
            	$i = 0;
            	while ($i < $sCount){
		            echo 
			            '<div class="article" id="scrollbar">
			            	<h2>UserId: '.$sponsor[$i][0].'</h2>
							<h2>Firstname: '.$sponsor[$i][1].'</h2>
							<h2>Lastname: '.$sponsor[$i][2].'</h2>
							<h2>1st Address: '.$sponsor[$i][3].'</h2>
							<h2>Postcode: '.$sponsor[$i][4].'</h2>
			                
			            </div>';
	            	$i++;
	            }
            ?>
            
        </div>
        
        <div id="navFoot">
            <nav> 
                <div class="menu"><a href="SponsorADog.html">MAKE A DONNATION</a></div>
                <div class="menu"><a href="Admin.html">CONTACT US</a></div>
                <div class="menu"><a href="Home.htmll">SOCIAL NETWORK</a></div>
                <div class="menu"><a href="Home.html">ABOUT US...</a></div> 
            </nav>  
        </div>
        <div id="foot">   
            <footer>
                <address>
                    Derby Dog Rescue.<br> 
                    Telephone Number 123-456-789<br>
                    2017 Derby Dogs<br>
                    Derby, UK
                </address>
                <p>Copyright (c)</p>
            </footer>
        </div>
	</body>
    
</html>
