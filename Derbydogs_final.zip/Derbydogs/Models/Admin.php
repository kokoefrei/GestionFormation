<?php
include_once 'database.php';

function news (){
	$pdo = initDB();
	$sql = "SELECT DateOfPub, Headline, Picture, BriefText
			FROM news
			ORDER BY DateOfPub DESC";
	$stmt = $pdo->prepare ($sql);
	
	if ($stmt->execute() === false)
		$return = "ERROR IN YOUR SQL EXECUTION";
		else
			$return = $stmt->fetchAll();
			
			return $return;
}

function adopted(){
	$pdo = initDB();
	$sql = "SELECT Name, Picture
			FROM dog
			WHERE Adopted = 1
			ORDER BY Name DESC";
	$stmt = $pdo->prepare ($sql);
	
	if ($stmt->execute() === false)
		$return = "ERROR IN YOUR SQL EXECUTION";
		else
			$return = $stmt->fetchAll();
			
			return $return;
}
function adoptedCount(){
	$pdo = initDB();
	$sql = "SELECT count(*)
			FROM dog
			WHERE Adopted = 1";
	$stmt = $pdo->prepare ($sql);
	
	if ($stmt->execute() === false)
		$return = "ERROR IN YOUR SQL EXECUTION";
		else
			$return = $stmt->fetch()[0];
			
			return $return;
}

function sponsorsCount(){
	$pdo = initDB();
	$sql = "SELECT count(DISTINCT u.userid)
			FROM user u, sponsordog s
			WHERE u.userid = s.UserId";
	$stmt = $pdo->prepare ($sql);
	
	if ($stmt->execute() === false)
		$return = "ERROR IN YOUR SQL EXECUTION";
		else
			$return = $stmt->fetch()[0];
			
			return $return;
}

function sponsor(){
	$pdo = initDB();
	$sql = "SELECT DISTINCT u.userid, firstname, lastname, address1, postcode
			FROM user u, sponsordog s
			WHERE u.userid = s.UserId
			ORDER BY u.userid";
	$stmt = $pdo->prepare ($sql);
	
	if ($stmt->execute() === false)
		$return = "ERROR IN YOUR SQL EXECUTION";
		else
			$return = $stmt->fetchAll();
			
			return $return;
}

function sDelete(){
	$pdo = initDB();
	$sql = "DELETE
			FROM sponsordog
			WHERE DogId IN 
				(SELECT DogId 
				FROM dog
				WHERE Adopted = 1) 
			OR DogId NOT IN
				(SELECT DogId
				FROM dog)";
	$stmt = $pdo->prepare ($sql);
	
	if ($stmt->execute() === false)
		$return = "ERROR IN YOUR SQL EXECUTION";
		else
			$return = "OK";
			
			return $return;
}

function dDelete(){
	$pdo = initDB();
	$sql = "DELETE
			FROM dog
			WHERE Adopted = 1";
	$stmt = $pdo->prepare ($sql);
	
	if ($stmt->execute() === false)
		$return = "ERROR IN YOUR SQL EXECUTION";
		else
			$return = "OK";
			
			return $return;
}


