<?php

include_once 'database.php';

function information($id){
	$pdo = initDB();
	$sql = "SELECT Name, Age, Picture, Gender
			FROM dog
			WHERE DogId = :lidentifiant ";
	$stmt = $pdo->prepare($sql);
	$stmt->bindParam(':lidentifiant', $id);
	
	if ($stmt->execute() === false)
		$return = "SQL ERROR";
		else
			$return = $stmt->fetch();
			
			return $return;
}

function findUser($id){
	$pdo = initDB();
	$sql = "SELECT count(*)
			FROM user
			WHERE UserId = :lidentifiant" ;
	$stmt = $pdo->prepare($sql);
	$stmt->bindParam(':lidentifiant', $id);
	
	if ($stmt->execute() === false)
		$return = "SQL ERROR";
		else
			$return = $stmt->fetch()[0];
			
			return $return;
}

function sponsor ($Userid,$DogId, $date, $amount){
	$pdo = initDB();
	$date = date('Y-m-d', strtotime($date));
	$sql = "INSERT INTO sponsordog
				(UserId, DogId, Date, Amount)
			VALUES (:User, :Dog, :Date, :Amount)";
	$stmt = $pdo->prepare($sql);
	$stmt->bindParam(':User', $Userid);
	$stmt->bindParam(':Dog', $DogId);
	$stmt->bindParam(':Date', $date);
	$stmt->bindParam(':Amount', $amount);
	
	if ($stmt->execute() === false)
		$return = "SQL ERROR";
		else
			$return = "OK";
			
			return $return;
}